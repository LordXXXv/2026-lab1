# Отчёт по лабораторной работе 1.1
**Тема:** Базовая настройка, ARP, статическая маршрутизация
**Выполнили:** Загребнева, Савочкин, Сковпень гр. 439

# Часть 1

## Шаг 1

### Настройка устройств (R1, R2, SW1)

Мы открыли окно Cisco Packet Tracer, собрали топологию согласно схеме, подключили устройства кабелями и вошли в консоль каждого устройства через вкладку CLI.
![Топология сети](<figures/Топология сети.png>)

### Базовая настройка (для всех устройств):

```
enable!
configure terminal
hostname <R1/SW1/R2>
no ip domain-lookup
service password-encryption
enable secret cisco
username admin privilege 15 secret cisco
line console 0
 logging synchronous
 login local
 speed 115200
 exit
```

Настройка интерфейсов R1:

```
interface Gi0/0
 description LAN1
 ip address 192.168.10.1 255.255.255.0
 no shutdown
 exit
interface Gi0/1
 description LAN2
 ip address 192.168.20.1 255.255.255.128
 no shutdown
 exit
interface Gi0/2
 description UPLINK
 ip address 10.10.12.2 255.255.255.252
 no shutdown
 exit
```

Настройка интерфейсов R2:

```
interface Gi0/0
 description ISP1
 ip address 100.0.102.130 255.255.255.252
 no shutdown
 exit
interface Gi0/1
 description ISP2
 ip address 100.0.202.130 255.255.255.252
 no shutdown
 exit
interface Gi0/2
 description DOWNLINK
 ip address 10.10.12.1 255.255.255.252
 no shutdown
 exit
```

Настройка SW1:

```
interface vlan 1
 ip address 192.168.10.254 255.255.255.0
 no shutdown
 exit
ip default-gateway 192.168.10.1
```

Статическая маршрутизация:

На R1:

```
ip route 100.0.102.0 255.255.255.252 10.10.12.1
ip route 100.0.202.0 255.255.255.252 10.10.12.1
``` 
На R2:

```
ip route 192.168.10.0 255.255.255.0 10.10.12.2
ip route 192.168.20.0 255.255.255.128 10.10.12.2
```

Сохранение:

```
end
copy running-config startup-config
```

---

### Настройка ПК (GUI Packet Tracer)

Мы дважды кликнули по каждому ПК, перешли на вкладку Desktop → IP Configuration и вручную вписали адреса.

ПК IP Маска Шлюз
![Настройки IP на PC0](<figures/Настройки IP на PC0.png>)
![Настройки IP на PC1](<figures/Настройки IP на PC1.png>)
![Настройки IP на PC2](<figures/Настройки IP на PC2.png>)

---

### Проверка 

Мы открыли командную строку на PC0 (Desktop → Command Prompt) и отправили эхо-запросы.

Пинги с PC0:

```
ping 192.168.10.101
ping 192.168.20.102
```

Результат: Успешно.

Просмотр таблиц:

На SW1:

```
show mac address-table
```

На PC0:

```
arp -a
```
На R1:

```
show arp
```

---
# Часть 2
## Шаг 1

### Симуляция

Мы переключились в Simulation Mode, открыли фильтры и оставили только ICMP. 
![Фильтр ICMP в симуляции](<figures/Фильтр ICMP в симуляции.png>)

Затем выбрали инструмент Add Simple PDU, кликнули по PC0, потом по PC2 и пошагово нажимали Play.

![Пакет на PC0](<figures/Пакет на PC0.png>)
![Исходящий пакет на R1](<figures/Исходящий пакет на R1.png>)

### Анализ PDU на PC0 (Outbound PDU Details):

· DEST MAC = MAC роутера R1 (Gi0/0).
· Причина: PC2 в другой подсети, отправка идет на шлюз.

### Анализ PDU на R1 (Outbound PDU Details):

· SRC MAC = MAC R1 (Gi0/1).
· DEST MAC = MAC PC2.
· Причина: Роутер переинкапсулирует кадр для доставки в целевую сеть.

---

# Часть 3
## Шаг 1

### ARP 

Мы открыли командную строку на PC0 (Desktop → Command Prompt) и очистили, а после проверили ARP таблицу.

```
arp -d
arp -a 
```

Далее мы в режиме симуляции с включенным фильтром ARP отправили эхо-запрос с РС0 на R1.

### Изучение сообщения ARP 

Мы открыли сообщение протокола ARP созданное на РС0:

TYPE: 0x0806
DEST-MAC: FFFF.FFFF.FFFF
Это широковещательный физический адрес, SW1 после получения такого Ethernet-кадра отправит его на все порты кроме порта с которого он был получен.
OPCODE: 0x0001
SOURCE-MAC: 0007.EC57.4C1B (PC0)
SOURCE-IP: 192.168.10.100 (PC0)
TARGET-MAC: 0000.0000.0000
Нулевой физический адрес понимает каждое устройство. Потому что на PC0 еще не знаем физический адрес R1.

---

### Изучение сообщения ARP от R1 

DEST-MAC: 0007.EC57.4C1B (PC0)
SW1 перенаправит кадр в нужный порт по таблице MAC-адресации.
OPCODE: 0x0002
SOURCE-MAC/IP принадлежат R1, а TARGET-MAC/IP PC0.

---
## Часть 4
## Шаг 1
### Настройка статической маршрутизации 

Команды для создания рекурсивного маршрута на R1.

```
configure terminal
ip route 0.0.0.0 0.0.0.0 10.10.12.1
end
write memory
```

Команды для создания рекурсивного маршрута на R2.

```
configure terminal
ip route 192.168.0.0 255.255.224.0 10.10.12.2
ip route 0.0.0.0 0.0.0.0 100.0.102.129
ip route 0.0.0.0 0.0.0.0 100.0.202.129 10
end
write memory
```

---

## Шаг 2

Next-Hop: 100.0.102.125

Next-Hop после аварии: 100.0.202.129

---